// Service worker: receives Web Push and shows the notification.
// iOS requires every push to display a notification (userVisibleOnly), so we always do.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

self.addEventListener('push', (event) => {
  let d = {};
  try { d = event.data ? event.data.json() : {}; }
  catch { d = { title: 'Pocket Signal Alert', body: event.data ? event.data.text() : '' }; }
  const opts = {
    body: d.body || '',
    tag: d.tag || 'pocket-signal',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    data: { url: d.url || '/' },
  };
  if (d.vibrate) opts.vibrate = d.vibrate;
  if (d.silent) opts.silent = true;
  event.waitUntil(self.registration.showNotification(d.title || 'Pocket Signal Alert', opts));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) if ('focus' in c) return c.focus();
      return self.clients.openWindow(url);
    }),
  );
});
