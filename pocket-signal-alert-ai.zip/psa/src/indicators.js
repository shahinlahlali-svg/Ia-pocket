// Pure indicator functions. Candle shape: { t: epoch ms (candle start), o, h, l, c }

export function ema(values, period) {
  const out = new Array(values.length).fill(NaN);
  if (values.length < period) return out;
  let sum = 0;
  for (let i = 0; i < period; i++) sum += values[i];
  let prev = sum / period;
  out[period - 1] = prev;
  const k = 2 / (period + 1);
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

// Wilder RSI
export function rsi(closes, period = 14) {
  const out = new Array(closes.length).fill(NaN);
  if (closes.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  gain /= period; loss /= period;
  out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    gain = (gain * (period - 1) + (d > 0 ? d : 0)) / period;
    loss = (loss * (period - 1) + (d < 0 ? -d : 0)) / period;
    out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  }
  return out;
}

// Wilder ATR (volatility)
export function atr(cs, period = 14) {
  const out = new Array(cs.length).fill(NaN);
  if (cs.length <= period) return out;
  const tr = (i) => Math.max(
    cs[i].h - cs[i].l,
    Math.abs(cs[i].h - cs[i - 1].c),
    Math.abs(cs[i].l - cs[i - 1].c),
  );
  let sum = 0;
  for (let i = 1; i <= period; i++) sum += tr(i);
  let prev = sum / period;
  out[period] = prev;
  for (let i = period + 1; i < cs.length; i++) {
    prev = (prev * (period - 1) + tr(i)) / period;
    out[i] = prev;
  }
  return out;
}

// Aggregate 1-minute candles into larger candles. Only COMPLETE buckets are returned,
// so a bucket with a missing minute is dropped rather than guessed.
export function aggregate(cs, seconds) {
  const ms = seconds * 1000;
  const need = seconds / 60;
  const buckets = new Map();
  for (const c of cs) {
    const k = Math.floor(c.t / ms) * ms;
    if (!buckets.has(k)) buckets.set(k, []);
    buckets.get(k).push(c);
  }
  const out = [];
  for (const [k, arr] of [...buckets.entries()].sort((a, b) => a[0] - b[0])) {
    if (arr.length < need) continue;
    arr.sort((a, b) => a.t - b.t);
    out.push({
      t: k,
      o: arr[0].o,
      h: Math.max(...arr.map((x) => x.h)),
      l: Math.min(...arr.map((x) => x.l)),
      c: arr[arr.length - 1].c,
    });
  }
  return out;
}

// Fractal swing highs/lows (k candles each side)
export function swings(cs, k = 2) {
  const highs = [], lows = [];
  for (let i = k; i < cs.length - k; i++) {
    let isHigh = true, isLow = true;
    for (let j = 1; j <= k; j++) {
      if (cs[i].h <= cs[i - j].h || cs[i].h <= cs[i + j].h) isHigh = false;
      if (cs[i].l >= cs[i - j].l || cs[i].l >= cs[i + j].l) isLow = false;
    }
    if (isHigh) highs.push({ i, price: cs[i].h });
    if (isLow) lows.push({ i, price: cs[i].l });
  }
  return { highs, lows };
}

export function median(arr) {
  const a = arr.filter(Number.isFinite).sort((x, y) => x - y);
  if (!a.length) return NaN;
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
}

export function candlePattern(prev, cur) {
  const body = Math.abs(cur.c - cur.o);
  const range = cur.h - cur.l || 1e-12;
  const lower = Math.min(cur.o, cur.c) - cur.l;
  const upper = cur.h - Math.max(cur.o, cur.c);
  if (body / range < 0.1) return { name: 'doji', bias: 0 };
  if (cur.c > cur.o && prev.c < prev.o && cur.c >= prev.o && cur.o <= prev.c) return { name: 'bullish engulfing', bias: 1 };
  if (cur.c < cur.o && prev.c > prev.o && cur.c <= prev.o && cur.o >= prev.c) return { name: 'bearish engulfing', bias: -1 };
  if (lower >= 2 * body && upper <= body) return { name: 'hammer', bias: 1 };
  if (upper >= 2 * body && lower <= body) return { name: 'shooting star', bias: -1 };
  return { name: 'none', bias: 0 };
}
