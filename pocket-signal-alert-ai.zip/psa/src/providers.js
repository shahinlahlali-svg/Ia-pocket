export class ProviderError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

/** Twelve Data (https://twelvedata.com) 1-minute candles. API key stays on the server. */
export function twelveData({ apiKey, baseUrl }, fetchFn = globalThis.fetch) {
  return {
    name: 'Twelve Data',
    isDemo: false,
    configured: Boolean(apiKey),
    async fetchCandles(pair, { outputsize = 300 } = {}) {
      if (!apiKey) throw new ProviderError('NO_KEY', 'No market-data API key configured');
      const url = `${baseUrl}/time_series?symbol=${encodeURIComponent(pair)}&interval=1min`
        + `&outputsize=${outputsize}&timezone=UTC&order=ASC&apikey=${encodeURIComponent(apiKey)}`;
      let res;
      try {
        res = await fetchFn(url, { signal: AbortSignal.timeout(8000) });
      } catch (e) {
        throw new ProviderError('NETWORK', `Market-data provider unreachable (${e.name})`);
      }
      const j = await res.json().catch(() => null);
      if (!j) throw new ProviderError('BAD_RESPONSE', 'Provider returned an unreadable response');
      if (j.status === 'error' || !Array.isArray(j.values)) {
        const code = j.code === 429 ? 'RATE_LIMIT' : (j.code === 401 || j.code === 403 ? 'AUTH' : 'API');
        throw new ProviderError(code, `Provider error: ${String(j.message || 'unknown').slice(0, 160)}`);
      }
      return j.values
        .map((v) => ({
          t: Date.parse(String(v.datetime).replace(' ', 'T') + 'Z'),
          o: +v.open, h: +v.high, l: +v.low, c: +v.close,
        }))
        .filter((c) => [c.t, c.o, c.h, c.l, c.c].every(Number.isFinite))
        .sort((a, b) => a.t - b.t);
    },
  };
}

/**
 * DEMO provider: synthetic random-walk candles with trending regimes.
 * NEVER real prices. Every signal produced from it is flagged demo and labelled DEMO.
 */
export function demoProvider(now = () => Date.now()) {
  const series = new Map();
  const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const startPrice = (pair) => (pair.includes('JPY') ? 150 : 1.1);

  function ensure(pair) {
    let s = series.get(pair);
    if (!s) {
      let seed = 7;
      for (const ch of pair) seed = (seed * 31 + ch.charCodeAt(0)) >>> 0;
      s = { rand: rng(seed), price: startPrice(pair), drift: 0, left: 0, candles: [] };
      series.set(pair, s);
      const cur = Math.floor(now() / 60000) * 60000;
      for (let i = 400; i >= 0; i--) step(s, pair, cur - i * 60000);
    }
    return s;
  }
  function step(s, pair, t) {
    const unit = startPrice(pair) * 0.00008;
    if (s.left <= 0) { s.drift = (s.rand() - 0.5) * unit * 0.8; s.left = 20 + Math.floor(s.rand() * 40); }
    s.left--;
    const o = s.price;
    let c = o;
    let h = o, l = o;
    for (let k = 0; k < 6; k++) {
      c += s.drift + (s.rand() - 0.5) * unit * 1.6;
      h = Math.max(h, c); l = Math.min(l, c);
    }
    s.price = c;
    const dp = pair.includes('JPY') ? 3 : 5;
    const r = (x) => +x.toFixed(dp);
    s.candles.push({ t, o: r(o), h: r(h), l: r(l), c: r(c) });
    if (s.candles.length > 1500) s.candles.shift();
  }

  return {
    name: 'DEMO (synthetic data)',
    isDemo: true,
    configured: true,
    async fetchCandles(pair) {
      const s = ensure(pair);
      const cur = Math.floor(now() / 60000) * 60000;
      let lastT = s.candles[s.candles.length - 1].t;
      while (lastT < cur) { lastT += 60000; step(s, pair, lastT); }
      return s.candles.slice(-300).map((c) => ({ ...c }));
    },
  };
}
