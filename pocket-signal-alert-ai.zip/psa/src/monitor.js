import { randomUUID } from 'node:crypto';
import { analyze as defaultAnalyze } from './analysis.js';
import { buildPayload, buildTestPayload, dayKey } from './notify.js';

const DAY = 24 * 3600 * 1000;

export class Monitor {
  constructor({ config, store, provider, push, analyzer = defaultAnalyze, now = () => Date.now(), log = console }) {
    Object.assign(this, { cfg: config, store, provider, push, analyzer, now, log });
    this.pairStatus = {};
    this.backoff = {};
    this.reqTimes = [];
    this.timer = null;
    this.running = false;
    this.lastCycleAt = null;
    this.nextCycleAt = null;
    this.prov = {
      state: provider.isDemo ? 'demo' : (provider.configured ? 'idle' : 'no-key'),
      message: provider.configured ? '' : 'No market-data API key configured',
      lastOkAt: null, lastErrorAt: null,
    };
    const d = store.data;
    const act = d.history.find((h) => h.id === d.activeId);
    this.active = act && this.now() < act.expiresAt ? act : null;
    if (!this.active) d.activeId = null;
  }

  // ---------- lifecycle ----------
  start() {
    this.store.data.settings.monitoring = true;
    this.store.save();
    this.schedule(true);
  }
  stop() {
    this.store.data.settings.monitoring = false;
    clearTimeout(this.timer);
    this.timer = null;
    this.nextCycleAt = null;
    this.store.save();
  }
  schedule(immediate = false) {
    clearTimeout(this.timer);
    const n = this.now();
    const delay = immediate ? 0 : 60000 - (n % 60000) + 5000; // 5s after each minute boundary
    this.nextCycleAt = n + delay;
    this.timer = setTimeout(async () => {
      try { await this.cycle(); } catch (e) { this.log.error?.('cycle failed:', e.message); }
      if (this.store.data.settings.monitoring) this.schedule(false);
    }, delay);
  }

  // ---------- core cycle ----------
  expireIfNeeded(now = this.now()) {
    if (this.active && now >= this.active.expiresAt) {
      this.active.expired = true;
      this.active = null;
      this.store.data.activeId = null;
      this.store.save();
    }
  }

  async cycle() {
    if (this.running) return;
    this.running = true;
    try {
      const now = this.now();
      this.lastCycleAt = now;
      this.expireIfNeeded(now);
      if (this.active) return; // ONE signal at a time: do nothing until it expires
      if (!this.inActiveHours(now)) {
        for (const p of this.store.data.settings.pairs) {
          this.pairStatus[p] = { ...(this.pairStatus[p] || {}), state: 'PAUSED', detail: 'Outside configured active hours', checkedAt: now };
        }
        return;
      }
      const found = [];
      for (const pair of this.store.data.settings.pairs) {
        const r = await this.checkPair(pair, now);
        if (r && (r.decision === 'CALL' || r.decision === 'PUT')) found.push(r);
      }
      const fresh = found.filter((r) => !this.isDuplicate(r, now));
      for (const r of found) {
        if (!fresh.includes(r)) this.pairStatus[r.pair].detail = 'Setup already alerted - duplicate suppressed';
      }
      if (fresh.length) {
        fresh.sort((a, b) => b.score - a.score || a.pair.localeCompare(b.pair));
        await this.fire(fresh[0], now);
      }
    } finally {
      this.running = false;
    }
  }

  inActiveHours(now) {
    const m = /^(\d{1,2})-(\d{1,2})$/.exec(this.cfg.activeHoursUtc || '');
    if (!m) return true;
    const h = new Date(now).getUTCHours(), a = +m[1], b = +m[2];
    return a <= b ? (h >= a && h < b) : (h >= a || h < b);
  }

  budget(now) {
    const u = this.store.data.usage;
    const today = new Date(now).toISOString().slice(0, 10);
    if (u.day !== today) { u.day = today; u.count = 0; }
    this.reqTimes = this.reqTimes.filter((t) => now - t < 60000);
    if (u.count >= this.cfg.dailyRequestLimit) return { ok: false, reason: 'Daily market-data request limit reached' };
    if (this.reqTimes.length >= this.cfg.perMinuteLimit) return { ok: false, reason: 'Per-minute market-data limit reached; skipped this minute' };
    return { ok: true };
  }

  async checkPair(pair, now) {
    const ps = (this.pairStatus[pair] = this.pairStatus[pair] || {});
    if ((this.backoff[pair] || 0) > now) return null; // keep last DATA UNAVAILABLE status, spare API credits
    const b = this.budget(now);
    if (!b.ok) {
      Object.assign(ps, { state: 'DATA UNAVAILABLE', detail: b.reason, checkedAt: now });
      return null;
    }
    let candles;
    try {
      this.reqTimes.push(now);
      this.store.data.usage.count++;
      candles = await this.provider.fetchCandles(pair, { outputsize: 300 });
      this.prov = { ...this.prov, state: this.provider.isDemo ? 'demo' : 'connected', message: '', lastOkAt: now };
    } catch (e) {
      this.prov = { ...this.prov, state: e.code === 'NO_KEY' ? 'no-key' : 'error', message: e.message, lastErrorAt: now };
      Object.assign(ps, { state: 'DATA UNAVAILABLE', detail: e.message, checkedAt: now });
      if (e.code === 'AUTH' || e.code === 'NO_KEY') this.backoff[pair] = now + 5 * 60000;
      return null;
    }
    const last = candles[candles.length - 1];
    if (!last) {
      Object.assign(ps, { state: 'DATA UNAVAILABLE', detail: 'Provider returned no candles', checkedAt: now });
      return null;
    }
    const ageSec = (now - last.t) / 1000;
    Object.assign(ps, { price: last.c, dataTime: last.t, ageSec: Math.round(ageSec), checkedAt: now });
    if (ageSec > this.cfg.maxDataAgeSec) {
      Object.assign(ps, {
        state: 'DATA UNAVAILABLE',
        detail: `Data is stale (${Math.round(ageSec)}s old). Market may be closed or the feed delayed`,
      });
      this.backoff[pair] = now + 5 * 60000;
      return null;
    }
    const closed = candles.filter((c) => c.t + 60000 <= now - 1000);
    const s = this.store.data.settings;
    const res = this.analyzer(closed, { minCandles: this.cfg.minCandles, minScore: s.minScore, expiries: s.expiries });
    Object.assign(ps, { state: res.decision === 'WAIT' ? 'WAIT' : 'SETUP', detail: res.summary, score: res.score, decision: res.decision });
    return {
      ...res, pair, price: last.c, dataTime: last.t,
      lastClosedT: closed.length ? closed[closed.length - 1].t : 0,
    };
  }

  isDuplicate(r, now) {
    const d = this.store.data;
    const key = `${r.pair}|${r.direction}`;
    if (d.fingerprints[`${key}|${r.lastClosedT}`]) return true;
    const at = d.lastSignalAt[key];
    return Boolean(at && now - at < this.cfg.cooldownSec * 1000);
  }

  async fire(r, now) {
    const d = this.store.data;
    const key = `${r.pair}|${r.direction}`;
    const entryBy = now + this.cfg.entryWindowSec * 1000;
    const sig = {
      id: randomUUID(), pair: r.pair, direction: r.direction, expirySec: r.expirySec,
      detectedAt: now, entryBy, expiresAt: entryBy + r.expirySec * 1000,
      price: r.price, dataTime: r.dataTime, score: r.score, maxScore: r.maxScore,
      parts: r.parts, warnings: r.warnings, summary: r.summary, indicators: r.indicators,
      demo: Boolean(this.provider.isDemo), result: null, push: null,
    };
    // Persist FIRST so a crash or push failure can never cause a duplicate alert.
    this.active = sig;
    d.history.unshift(sig);
    if (d.history.length > 500) d.history.length = 500;
    d.activeId = sig.id;
    d.fingerprints[`${key}|${r.lastClosedT}`] = now;
    d.lastSignalAt[key] = now;
    for (const [k, t] of Object.entries(d.fingerprints)) if (now - t > DAY) delete d.fingerprints[k];
    this.store.save();
    sig.push = await this.sendAll(buildPayload(sig, d.settings));
    this.store.save();
    return sig;
  }

  async sendAll(payload) {
    const subs = this.store.data.subscriptions;
    if (!this.push.configured) return { sent: 0, failed: 0, error: 'Push not configured (VAPID keys missing)' };
    if (!subs.length) return { sent: 0, failed: 0, error: 'No device is subscribed to notifications' };
    let sent = 0, failed = 0;
    const errors = new Set(), gone = [];
    await Promise.all(subs.map(async (sub) => {
      try { await this.push.send(sub, payload); sent++; }
      catch (e) {
        failed++;
        if (e.statusCode === 404 || e.statusCode === 410) gone.push(sub.endpoint);
        else errors.add(String(e.statusCode || e.message).slice(0, 80));
      }
    }));
    if (gone.length) this.store.data.subscriptions = subs.filter((s) => !gone.includes(s.endpoint));
    return { sent, failed, removed: gone.length, errors: [...errors].slice(0, 3) };
  }

  async sendTest() {
    const r = await this.sendAll(buildTestPayload());
    this.store.data.lastTestPush = { at: this.now(), ...r };
    this.store.save();
    return r;
  }

  // ---------- history ----------
  recordOutcome(id, result) {
    if (!['win', 'loss', 'skip'].includes(result)) return false;
    const h = this.store.data.history.find((x) => x.id === id);
    if (!h) return false;
    h.result = result;
    this.store.save();
    return true;
  }
  resetHistory() {
    const d = this.store.data;
    d.history = []; d.fingerprints = {}; d.lastSignalAt = {};
    this.active = null; d.activeId = null;
    this.store.save();
  }
  stats() {
    const one = (demo) => {
      const rows = this.store.data.history.filter((h) => Boolean(h.demo) === demo);
      const wins = rows.filter((h) => h.result === 'win').length;
      const losses = rows.filter((h) => h.result === 'loss').length;
      const verified = wins + losses;
      return { total: rows.length, verified, wins, losses, winRate: verified ? wins / verified : null };
    };
    return { live: one(false), demo: one(true) };
  }

  // ---------- status ----------
  getStatus() {
    const now = this.now();
    this.expireIfNeeded(now);
    const d = this.store.data, s = d.settings;
    const today = dayKey(now, s.tz);
    const pairs = s.pairs.map((p) => ({ pair: p, ...(this.pairStatus[p] || { state: 'PENDING', detail: 'Waiting for first check' }) }));
    let state = 'STOPPED';
    if (s.monitoring) {
      if (this.active) state = 'ACTIVE SIGNAL';
      else if (pairs.length && pairs.every((p) => p.state === 'DATA UNAVAILABLE')) state = 'DATA UNAVAILABLE';
      else if (pairs.some((p) => p.state === 'SETUP')) state = 'SETUP';
      else state = 'WAIT';
    }
    return {
      serverTime: now, state, monitoring: s.monitoring,
      provider: { name: this.provider.name, demo: Boolean(this.provider.isDemo), ...this.prov },
      pairs, active: this.active,
      latest: d.history[0] || null,
      signalsToday: d.history.filter((h) => dayKey(h.detectedAt, s.tz) === today).length,
      lastCycleAt: this.lastCycleAt, nextCycleAt: this.nextCycleAt,
      apiUsageToday: d.usage.count, apiDailyLimit: this.cfg.dailyRequestLimit,
      push: {
        configured: Boolean(this.push.configured), devices: d.subscriptions.length,
        lastTest: d.lastTestPush, verifiedAt: d.pushVerifiedAt,
      },
      settings: s, stats: this.stats(),
    };
  }
}
