const num = (v, d) => {
  if (v === undefined || v === '') return d;
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

export function loadConfig(env = process.env) {
  return {
    port: num(env.PORT, 3000),
    appKey: env.APP_KEY || '',
    dataDir: env.DATA_DIR || './data',
    demoMode: env.DEMO_MODE === 'true',
    provider: {
      apiKey: env.TWELVE_DATA_API_KEY || '',
      baseUrl: env.TWELVE_DATA_URL || 'https://api.twelvedata.com',
    },
    vapid: {
      publicKey: env.VAPID_PUBLIC_KEY || '',
      privateKey: env.VAPID_PRIVATE_KEY || '',
      subject: env.VAPID_SUBJECT || '',
    },
    maxDataAgeSec: num(env.MAX_DATA_AGE_SEC, 90),
    minCandles: num(env.MIN_CANDLES, 150),
    entryWindowSec: num(env.ENTRY_WINDOW_SEC, 20),
    cooldownSec: num(env.COOLDOWN_SEC, 600),
    perMinuteLimit: num(env.PER_MINUTE_LIMIT, 8),
    dailyRequestLimit: num(env.DAILY_REQUEST_LIMIT, 800),
    activeHoursUtc: env.ACTIVE_HOURS_UTC || '',
    availablePairs: (env.PAIRS || 'EUR/USD,GBP/USD,USD/JPY,AUD/USD,USD/CAD,USD/CHF,NZD/USD,EUR/GBP,EUR/JPY,GBP/JPY')
      .split(',').map((s) => s.trim()).filter(Boolean),
  };
}
