import fs from 'node:fs';
import path from 'node:path';

const defaults = () => ({
  settings: {
    pairs: ['EUR/USD'], expiries: [60, 300], minScore: 6,
    sound: true, vibrate: true, tz: 'UTC', monitoring: false,
  },
  subscriptions: [],
  history: [],
  activeId: null,
  fingerprints: {},
  lastSignalAt: {},
  usage: { day: '', count: 0 },
  lastTestPush: null,
  pushVerifiedAt: null,
});

/** Tiny JSON-file store with atomic writes. Mount DATA_DIR on a persistent volume. */
export class Store {
  constructor(dir) {
    this.file = path.join(dir, 'state.json');
    fs.mkdirSync(dir, { recursive: true });
    const base = defaults();
    this.data = base;
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.data = { ...base, ...raw, settings: { ...base.settings, ...(raw.settings || {}) } };
    } catch { /* first run */ }
  }
  save() {
    const tmp = `${this.file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.data));
    fs.renameSync(tmp, this.file);
  }
}
