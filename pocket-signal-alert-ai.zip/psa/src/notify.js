export const EXPIRY_LABEL = { 30: '30 seconds', 60: '1 minute', 300: '5 minutes' };
export const expiryLabel = (s) => EXPIRY_LABEL[s] || `${s} seconds`;

export function fmtTime(ts, tz = 'UTC', withSeconds = true) {
  try {
    return new Intl.DateTimeFormat('en-GB', {
      timeZone: tz, hour: '2-digit', minute: '2-digit', second: withSeconds ? '2-digit' : undefined,
      hour12: false, timeZoneName: 'short',
    }).format(new Date(ts));
  } catch {
    return new Date(ts).toISOString().slice(11, 19) + ' UTC';
  }
}

export function dayKey(ts, tz = 'UTC') {
  try {
    return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(ts));
  } catch {
    return new Date(ts).toISOString().slice(0, 10);
  }
}

/** Builds the Web Push payload shown on the iPhone lock screen. */
export function buildPayload(sig, settings) {
  const tz = settings.tz || 'UTC';
  const demo = sig.demo ? 'DEMO ' : '';
  return {
    title: `${demo}POCKET SIGNAL ALERT`,
    body: [
      `${sig.pair} \u00b7 ${sig.direction} \u00b7 ${expiryLabel(sig.expirySec)} \u2014 new setup detected`,
      `Enter by ${fmtTime(sig.entryBy, tz)}. Price ${sig.price} (data ${fmtTime(sig.dataTime, tz)})`,
      `Checklist ${sig.score}/${sig.maxScore}. Risky, not guaranteed.`,
      'Open the app to review before entering manually.',
    ].join('\n'),
    tag: `signal-${sig.id}`,
    url: '/',
    vibrate: settings.vibrate ? [200, 100, 200] : undefined,
    silent: settings.sound ? undefined : true,
  };
}

export function buildTestPayload() {
  return {
    title: 'TEST NOTIFICATION',
    body: 'This is a test of your alert setup. It is NOT a trading signal.',
    tag: `test-${Date.now()}`,
    url: '/',
  };
}
