import { ema, rsi, atr, aggregate, swings, median, candlePattern } from './indicators.js';

export const MAX_SCORE = 7;

/**
 * Strict rule-based setup detector. Input: CLOSED 1-minute candles (oldest -> newest).
 * Returns decision CALL | PUT | WAIT. WAIT is the default; a signal needs
 * score >= minScore AND zero vetoes AND no contradicting opposite setup.
 * The score is a rule checklist count, NOT a probability of winning.
 */
export function analyze(candles, opts = {}) {
  const o = { minCandles: 150, minScore: 6, expiries: [60, 300], ...opts };
  const out = {
    decision: 'WAIT', direction: null, score: 0, maxScore: MAX_SCORE,
    summary: '', parts: [], vetoes: [], warnings: [], indicators: null,
    expirySec: null, price: null,
  };
  const n = candles.length;
  if (n < o.minCandles) {
    out.summary = `Not enough data: ${n}/${o.minCandles} closed 1-minute candles`;
    out.vetoes.push(out.summary);
    return out;
  }

  // Data integrity: no meaningful gaps in the analysis window
  const win = candles.slice(-o.minCandles);
  let gaps = 0;
  for (let i = 1; i < win.length; i++) gaps += Math.max(0, (win[i].t - win[i - 1].t) / 60000 - 1);
  if (gaps > 3) {
    out.summary = `Data has ${gaps} missing candles in the analysis window`;
    out.vetoes.push(out.summary);
    return out;
  }

  const closes = candles.map((c) => c.c);
  const e9 = ema(closes, 9), e21 = ema(closes, 21);
  const r = rsi(closes, 14);
  const a = atr(candles, 14);
  const L = n - 1, last = candles[L], prev = candles[L - 1];
  const atrNow = a[L];
  const atrMed = median(a.slice(-100));
  const ratio = atrNow / atrMed;

  const c5 = aggregate(candles, 300);
  const cl5 = c5.map((c) => c.c);
  const e9_5 = ema(cl5, 9), e21_5 = ema(cl5, 21);
  const L5 = c5.length - 1;
  const gap5 = e9_5[L5] - e21_5[L5];
  const slope5 = e21_5[L5] - e21_5[L5 - 3];

  const vals = [e9[L], e21[L], r[L], r[L - 2], atrNow, atrMed, gap5, slope5];
  if (!vals.every(Number.isFinite)) {
    out.summary = 'Indicators could not be calculated from the available data';
    out.vetoes.push(out.summary);
    return out;
  }

  // Support / resistance from recent swing points (last 90 candles)
  const sw = swings(candles.slice(-90), 2);
  const above = sw.highs.map((h) => h.price).filter((p) => p > last.c);
  const below = sw.lows.map((l) => l.price).filter((p) => p < last.c);
  const resistance = above.length ? Math.min(...above) : null;
  const support = below.length ? Math.max(...below) : null;
  const pattern = candlePattern(prev, last);

  out.price = last.c;
  out.indicators = {
    ema9: e9[L], ema21: e21[L], rsi: r[L], atr: atrNow, atrRatio: ratio,
    trend5m: gap5 > 0 ? 'up' : 'down', support, resistance, pattern: pattern.name,
  };

  // Global vetoes
  const globalVetoes = [];
  if (ratio < 0.6) globalVetoes.push(`Volatility too low (ATR ${ratio.toFixed(2)}x normal) - market is flat`);
  if (ratio > 2.0) globalVetoes.push(`Volatility too high (ATR ${ratio.toFixed(2)}x normal) - price is erratic`);
  if (pattern.name === 'doji') globalVetoes.push('Latest candle is a doji (indecision)');

  const evalDir = (d) => {
    const word = d === 1 ? 'up' : 'down';
    const parts = [];
    const add = (key, weight, ok, text) => parts.push({ key, weight, ok, text });

    add('trend5m', 2, d * gap5 > 0 && d * slope5 > 0,
      `5-minute trend ${word}: EMA9 ${gap5 > 0 ? 'above' : 'below'} EMA21, EMA21 ${slope5 > 0 ? 'rising' : 'falling'}`);

    add('trend1m', 1, d * (e9[L] - e21[L]) > 0 && d * (e21[L] - e21[L - 5]) > 0,
      `1-minute trend ${word}: EMA9 ${e9[L] > e21[L] ? 'above' : 'below'} EMA21`);

    let touched = false;
    for (let i = L - 5; i < L; i++) {
      if (d === 1 ? candles[i].l <= e21[i] + 0.25 * atrNow : candles[i].h >= e21[i] - 0.25 * atrNow) touched = true;
    }
    add('pullback', 1, touched && d * (last.c - e9[L]) > 0,
      touched ? 'Pullback to EMA21 completed and price resumed above/below EMA9'
              : 'No recent pullback to EMA21 (price is extended)');

    const body = Math.abs(last.c - last.o), range = last.h - last.l || 1e-12;
    const closePos = (last.c - last.l) / range;
    const dirOk = (d === 1 ? last.c > last.o : last.c < last.o);
    add('candle', 1,
      dirOk && body >= 0.4 * atrNow && (d === 1 ? closePos >= 0.6 : closePos <= 0.4),
      `Confirmation candle ${dirOk ? 'agrees' : 'disagrees'} (pattern: ${pattern.name})`);

    const rsiOk = d === 1 ? (r[L] >= 45 && r[L] <= 68 && r[L] > r[L - 2])
                          : (r[L] >= 32 && r[L] <= 55 && r[L] < r[L - 2]);
    add('rsi', 1, rsiOk, `RSI ${r[L].toFixed(1)} ${rsiOk ? 'supports' : 'does not support'} the move`);

    const opp = d === 1 ? resistance : support;
    const room = opp == null ? Infinity : Math.abs(opp - last.c) / atrNow;
    add('room', 1, room >= 1.5,
      opp == null ? 'No nearby opposing support/resistance in the last 90 candles'
                  : `${room.toFixed(1)} ATR of room to ${d === 1 ? 'resistance' : 'support'}`);

    const vetoes = [];
    if (d === 1 && r[L] > 72) vetoes.push(`RSI ${r[L].toFixed(1)} is overbought - CALL blocked`);
    if (d === -1 && r[L] < 28) vetoes.push(`RSI ${r[L].toFixed(1)} is oversold - PUT blocked`);
    if (d * gap5 < 0) vetoes.push('5-minute trend opposes this direction');
    if (opp != null && room < 0.5) vetoes.push(`Price is within 0.5 ATR of ${d === 1 ? 'resistance' : 'support'}`);

    const score = parts.reduce((s, p) => s + (p.ok ? p.weight : 0), 0);
    return { d, parts, vetoes, score };
  };

  const call = evalDir(1), put = evalDir(-1);
  const valid = [call, put].filter((x) => x.score >= o.minScore && x.vetoes.length === 0);

  if (globalVetoes.length) {
    out.vetoes = globalVetoes;
    out.summary = globalVetoes[0];
    const best = call.score >= put.score ? call : put;
    out.score = best.score; out.parts = best.parts;
    return out;
  }

  if (valid.length === 0) {
    const best = call.score >= put.score ? call : put;
    out.score = best.score;
    out.parts = best.parts;
    out.vetoes = best.vetoes;
    out.summary = best.vetoes[0]
      || `No high-quality setup (best ${best.d === 1 ? 'CALL' : 'PUT'} checklist ${best.score}/${MAX_SCORE}, need ${o.minScore})`;
    return out;
  }

  valid.sort((x, y) => y.score - x.score);
  const chosen = valid[0];
  const other = chosen === call ? put : call;
  if (other.score >= 4) {
    out.score = chosen.score; out.parts = chosen.parts;
    out.vetoes = [`Contradictory signals: opposite direction also scores ${other.score}/${MAX_SCORE}`];
    out.summary = out.vetoes[0];
    return out;
  }

  const want = (chosen.score >= 7 && Math.abs(gap5) >= atrNow) ? 300 : 60;
  const allowed = o.expiries?.length ? o.expiries : [60, 300];
  const expirySec = allowed.reduce((b, v) => (Math.abs(v - want) < Math.abs(b - want) ? v : b), allowed[0]);

  out.decision = chosen.d === 1 ? 'CALL' : 'PUT';
  out.direction = out.decision;
  out.score = chosen.score;
  out.parts = chosen.parts;
  out.expirySec = expirySec;
  out.summary = `${out.decision} setup: ${chosen.score}/${MAX_SCORE} checklist rules met, no vetoes`;
  if (ratio > 1.5) out.warnings.push(`Elevated volatility (ATR ${ratio.toFixed(2)}x normal)`);
  if (support == null && resistance == null) out.warnings.push('Support/resistance could not be located');
  return out;
}
