/** Web Push sender (VAPID). `web-push` is loaded lazily so tests can inject a fake. */
export async function createPush(vapid) {
  const configured = Boolean(vapid.publicKey && vapid.privateKey && vapid.subject);
  if (!configured) return { configured: false, publicKey: '', send: async () => { throw new Error('Push not configured'); } };
  const webpush = (await import('web-push')).default;
  webpush.setVapidDetails(vapid.subject, vapid.publicKey, vapid.privateKey);
  return {
    configured: true,
    publicKey: vapid.publicKey,
    // Short TTL: a stale trading alert is worse than none.
    send: (sub, payload, ttl = 45) => webpush.sendNotification(sub, JSON.stringify(payload), { TTL: ttl, urgency: 'high' }),
  };
}
