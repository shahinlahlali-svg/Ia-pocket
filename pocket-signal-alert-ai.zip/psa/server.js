import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { loadConfig } from './src/config.js';
import { Store } from './src/store.js';
import { Monitor } from './src/monitor.js';
import { twelveData, demoProvider } from './src/providers.js';
import { createPush } from './src/push.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(__dirname, 'public');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml',
};
const EXPIRIES = [30, 60, 300];

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();

export function createApp({ config, store, monitor, push }) {
  const failures = new Map(); // ip -> {n, t}

  const send = (res, code, body, headers = {}) => {
    const isStr = typeof body === 'string' || Buffer.isBuffer(body);
    res.writeHead(code, {
      'Content-Type': isStr ? 'text/plain; charset=utf-8' : 'application/json',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      ...headers,
    });
    res.end(isStr ? body : JSON.stringify(body));
  };

  const readJson = (req) => new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 100_000) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {}); } catch { reject(new Error('bad json')); } });
    req.on('error', reject);
  });

  const authorized = (req) => {
    const key = req.headers['x-app-key'];
    return typeof key === 'string' && crypto.timingSafeEqual(sha(key), sha(config.appKey));
  };

  function validSubscription(s) {
    try {
      const u = new URL(s.endpoint);
      return u.protocol === 'https:' && typeof s.keys?.p256dh === 'string' && typeof s.keys?.auth === 'string';
    } catch { return false; }
  }

  async function api(req, res, url) {
    const ip = req.socket.remoteAddress || '?';
    const f = failures.get(ip);
    if (f && f.n >= 20 && Date.now() - f.t < 10 * 60000) return send(res, 429, { error: 'Too many failed attempts. Try again later.' });

    if (req.method === 'GET' && url.pathname === '/api/health') return send(res, 200, { ok: true });
    if (req.method === 'GET' && url.pathname === '/api/vapid-public-key') return send(res, 200, { publicKey: push.publicKey || '' });

    if (!authorized(req)) {
      failures.set(ip, { n: (f && Date.now() - f.t < 10 * 60000 ? f.n : 0) + 1, t: Date.now() });
      return send(res, 401, { error: 'Invalid or missing app key' });
    }
    failures.delete(ip);

    const m = req.method, p = url.pathname;
    try {
      if (m === 'GET' && p === '/api/config') {
        return send(res, 200, {
          pairs: config.availablePairs, expiries: EXPIRIES, demo: config.demoMode,
          push: { configured: push.configured, publicKey: push.publicKey || '' },
          provider: monitor.provider.name,
        });
      }
      if (m === 'GET' && p === '/api/status') return send(res, 200, monitor.getStatus());
      if (m === 'POST' && p === '/api/monitor/start') { monitor.start(); return send(res, 200, monitor.getStatus()); }
      if (m === 'POST' && p === '/api/monitor/stop') { monitor.stop(); return send(res, 200, monitor.getStatus()); }

      if (m === 'POST' && p === '/api/settings') {
        const b = await readJson(req), s = store.data.settings;
        if (b.pairs !== undefined) {
          if (!Array.isArray(b.pairs) || b.pairs.length < 1 || b.pairs.length > 10 || !b.pairs.every((x) => config.availablePairs.includes(x))) {
            return send(res, 400, { error: 'Choose 1-10 pairs from the available list' });
          }
          s.pairs = [...new Set(b.pairs)];
        }
        if (b.expiries !== undefined) {
          if (!Array.isArray(b.expiries) || !b.expiries.length || !b.expiries.every((x) => EXPIRIES.includes(x))) {
            return send(res, 400, { error: 'Expiries must be a non-empty subset of 30, 60, 300' });
          }
          s.expiries = [...new Set(b.expiries)].sort((a, c) => a - c);
        }
        if (b.minScore !== undefined) {
          if (![5, 6, 7].includes(b.minScore)) return send(res, 400, { error: 'minScore must be 5, 6 or 7' });
          s.minScore = b.minScore;
        }
        if (b.tz !== undefined) {
          try { new Intl.DateTimeFormat('en', { timeZone: b.tz }); s.tz = b.tz; } catch { return send(res, 400, { error: 'Unknown time zone' }); }
        }
        if (b.sound !== undefined) s.sound = Boolean(b.sound);
        if (b.vibrate !== undefined) s.vibrate = Boolean(b.vibrate);
        store.save();
        return send(res, 200, monitor.getStatus());
      }

      if (m === 'POST' && p === '/api/subscribe') {
        const b = await readJson(req);
        if (!validSubscription(b.subscription || {})) return send(res, 400, { error: 'Invalid push subscription' });
        const subs = store.data.subscriptions.filter((x) => x.endpoint !== b.subscription.endpoint);
        subs.push({ endpoint: b.subscription.endpoint, keys: { p256dh: b.subscription.keys.p256dh, auth: b.subscription.keys.auth } });
        store.data.subscriptions = subs.slice(-10);
        store.save();
        return send(res, 200, { ok: true, devices: store.data.subscriptions.length });
      }
      if (m === 'POST' && p === '/api/unsubscribe') {
        const b = await readJson(req);
        store.data.subscriptions = store.data.subscriptions.filter((x) => x.endpoint !== b.endpoint);
        store.save();
        return send(res, 200, { ok: true, devices: store.data.subscriptions.length });
      }
      if (m === 'POST' && p === '/api/test-push') {
        const r = await monitor.sendTest();
        return send(res, 200, r);
      }
      if (m === 'POST' && p === '/api/test-push/confirm') {
        store.data.pushVerifiedAt = Date.now(); store.save();
        return send(res, 200, { ok: true });
      }

      if (m === 'GET' && p === '/api/history') return send(res, 200, { history: store.data.history.slice(0, 100), stats: monitor.stats() });
      const om = /^\/api\/history\/([\w-]+)\/outcome$/.exec(p);
      if (m === 'POST' && om) {
        const b = await readJson(req);
        return monitor.recordOutcome(om[1], b.result) ? send(res, 200, { ok: true, stats: monitor.stats() }) : send(res, 400, { error: 'Unknown signal or invalid result' });
      }
      if (m === 'DELETE' && p === '/api/history') { monitor.resetHistory(); return send(res, 200, { ok: true }); }
    } catch (e) {
      return send(res, 400, { error: e.message });
    }
    return send(res, 404, { error: 'Not found' });
  }

  function serveStatic(req, res, url) {
    let rel = decodeURIComponent(url.pathname);
    if (rel === '/') rel = '/index.html';
    const file = path.normalize(path.join(PUBLIC, rel));
    if (!file.startsWith(PUBLIC + path.sep)) return send(res, 403, 'Forbidden');
    fs.readFile(file, (err, buf) => {
      if (err) return send(res, 404, 'Not found');
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
        'Cache-Control': rel === '/sw.js' || rel === '/index.html' ? 'no-cache' : 'public, max-age=3600',
        'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'no-referrer',
      });
      res.end(buf);
    });
  }

  return http.createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) {
      api(req, res, url).catch((e) => send(res, 500, { error: 'Server error' }));
    } else if (req.method === 'GET' || req.method === 'HEAD') {
      serveStatic(req, res, url);
    } else send(res, 405, 'Method not allowed');
  });
}

// ---------------- entrypoint ----------------
const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const config = loadConfig();
  if (config.appKey.length < 16) {
    console.error('APP_KEY must be set to a random string of at least 16 characters (see .env.example).');
    process.exit(1);
  }
  const store = new Store(config.dataDir);
  const provider = config.demoMode ? demoProvider() : twelveData(config.provider);
  const push = await createPush(config.vapid);
  const monitor = new Monitor({ config, store, provider, push });
  const server = createApp({ config, store, monitor, push });
  server.listen(config.port, () => {
    console.log(`Pocket Signal Alert AI listening on :${config.port}`);
    console.log(`Data provider: ${provider.name}${provider.configured ? '' : ' (NO API KEY: live signals disabled)'}`);
    console.log(`Web Push: ${push.configured ? 'configured' : 'NOT configured (set VAPID_* variables)'}`);
    if (store.data.settings.monitoring) { console.log('Resuming monitoring'); monitor.start(); }
  });
  for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { try { store.save(); } catch {} process.exit(0); });
}
