# Pocket Signal Alert AI

A self-hosted market-monitoring assistant that watches selected currency pairs using a **legitimate market-data API**, applies strict rule-based filters, and sends **one** iPhone push notification when a high-quality setup appears. You decide whether to trade, and you enter any trade yourself, manually.

## What it is not

- It does **not** connect to Pocket Option, ask for Pocket Option credentials/cookies/API keys, place trades, or deposit money. Pocket Option has no official public data/trading API.
- It does **not** predict the market. A signal means "a checklist of rules was satisfied", not "this will win". Nothing here is guaranteed or financial advice. Short-expiry trading is high risk.
- Prices come from your data provider, not from Pocket Option. They can differ from the platform's quotes (especially OTC assets, which this app does not cover). Always check the live price and payout on your broker before entering.

## How it works

```
Twelve Data API --1-min candles--> Monitor (server, every minute at :05)
                                      |  freshness + completeness checks
                                      |  Analysis engine (EMA, RSI, ATR, 5-min trend, S/R, candle patterns)
                                      |  one-active-signal gate + duplicate/cooldown gate
                                      v
                          Web Push (VAPID) --> iPhone (installed PWA) --> you review in app --> manual decision
```

**Signal rules** (`src/analysis.js`). A CALL or PUT needs a checklist score of at least 6 of 7 (adjustable 5-7) **and** zero vetoes:

| Rule (weight) | Meaning |
|---|---|
| 5-minute trend (2) | EMA9 vs EMA21 and EMA21 slope agree with the direction |
| 1-minute trend (1) | same on 1-minute candles |
| Pullback (1) | price recently touched EMA21 and resumed above/below EMA9 |
| Confirmation candle (1) | latest closed candle agrees, with a decent body |
| RSI (1) | in a healthy range and moving the right way |
| Room (1) | at least 1.5 ATR to the nearest opposing support/resistance |

Vetoes (any one forces **WAIT**): RSI over 72 for CALL / under 28 for PUT, opposing 5-minute trend, price within 0.5 ATR of opposing S/R, volatility below 0.6x or above 2x normal, doji candle, missing candles, fewer than 150 closed candles, or a contradicting opposite setup.

**Safety gates** (`src/monitor.js`): data older than `MAX_DATA_AGE_SEC` shows **DATA UNAVAILABLE** and issues nothing; only one signal is active at a time (no fetching or alerting until it expires); the same pair+direction is not re-alerted within `COOLDOWN_SEC`, and the same candle never signals twice; the signal is saved *before* the push is sent, so a crash cannot cause a duplicate.

**Expiry.** Analysis uses 1-minute candles, so it suggests **1 minute or 5 minutes**. 30 seconds is selectable, but it is only used if it is the only expiry you allow, and it is a rough guess because the data cannot resolve 30-second moves.

## External services and keys you need

| What | Why | Where |
|---|---|---|
| **Twelve Data API key** (`TWELVE_DATA_API_KEY`) | Real forex candles. Check that your plan includes forex 1-minute data and its delay. | twelvedata.com. Free plan: 8 requests/min and 800/day, so around one pair for ~13 hours/day. Use a paid plan, fewer pairs, or `ACTIVE_HOURS_UTC`. |
| **VAPID keys** (`VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`) | Identifies your server to Apple's push service. | Run `npm run vapid`. Subject is `mailto:you@example.com`. |
| **`APP_KEY`** | Protects your API so only you can start/stop, subscribe and read history. | Make one: `openssl rand -hex 24`. |
| **An always-on HTTPS host** | Push needs HTTPS and a server that never sleeps. A sleeping free tier will **miss signals**. | Fly.io, Railway, a small VPS with Caddy, or Render (paid, not free). Mount a persistent disk at `DATA_DIR`. |

No Apple Developer account or App Store listing is needed; Web Push goes through Safari.

## Setup

```bash
npm install
cp .env.example .env        # fill in the values, then load them (e.g. node --env-file=.env server.js)
npm run vapid               # paste both keys into .env
npm test                    # 27 tests, no network needed
node --env-file=.env server.js
```

Docker: `docker build -t psa . && docker run -p 3000:3000 --env-file .env -v psa-data:/data psa`.

Try it first without any keys but `APP_KEY`: set `DEMO_MODE=true`. Everything is then labelled **DEMO** and uses synthetic prices. Never trade on DEMO signals.

## iPhone installation and notifications

1. iOS **16.4 or newer**; the site must be served over **HTTPS**.
2. Open the site in **Safari**, enter your app key.
3. **Share, then Add to Home Screen, then Add.** Open the new "Signal Alert" icon (notifications will not work from a normal Safari tab).
4. **Alerts** tab, then **Enable notifications**, then **Allow**.
5. **Send test notification**, lock the phone, and confirm it arrives, then tap "Yes, it arrived". Until you do, the app shows background alerts as **not verified**.
6. In **Monitor**, tap **Start monitoring**.

Notes: iPhone controls sound and vibration (Settings > Notifications > Signal Alert); Focus modes silence alerts; alerts have a 45-second TTL so a stale signal is dropped rather than delivered late.

## Dashboard

Monitoring status and start/stop, data-provider connection, per-pair status (WAIT / SETUP / DATA UNAVAILABLE), latest signal with entry-window and expiry countdowns, signals today, history with manually recorded outcomes, and win/loss statistics computed only from outcomes you record (live and DEMO kept separate).

## What was and was not tested

Tested here (27 automated tests, `npm test`): the analysis engine on synthetic candles (CALL, PUT, flat, overbought, volatility spike, gaps, too little data); one-signal-at-a-time, duplicate and cooldown suppression, stale-data and provider-failure handling, quota guard, expired-subscription cleanup, restart without re-alerting; API authentication, validation and path-traversal protection; and the UI loading in a headless mobile browser against the DEMO provider.

**Not tested in this build:** real Twelve Data responses, delivery of a real push to a real iPhone, and live-market signal quality (no backtest was run). The code follows the documented Twelve Data and Web Push APIs, but you must run the checklist above (especially the test notification) on your own deployment before relying on it. Signal quality is unproven: forward-test in DEMO and with recorded outcomes before risking money.

## Files

`server.js` HTTP API and static hosting; `src/analysis.js` + `src/indicators.js` signal engine; `src/monitor.js` scheduler, gates, history; `src/providers.js` Twelve Data and DEMO; `src/push.js` Web Push; `public/` PWA (dashboard, `sw.js`, manifest, icons); `test/` automated tests.
