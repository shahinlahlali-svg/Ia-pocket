import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Store } from '../src/store.js';
import { loadConfig } from '../src/config.js';

export const MIN = 60000;
export const T0 = Date.UTC(2026, 9, 13, 12, 0, 5); // 12:00:05 UTC, a Tuesday

export function tmpStore() {
  return new Store(fs.mkdtempSync(path.join(os.tmpdir(), 'psa-')));
}

export function cfg(over = {}) {
  return { ...loadConfig({ APP_KEY: 'k'.repeat(20) }), ...over };
}

/** n flat-ish 1-minute candles; the last one starts at the current (forming) minute. */
export function candlesUntil(nowMs, n = 200, price = 1.1) {
  const cur = Math.floor(nowMs / MIN) * MIN;
  const out = [];
  for (let i = n - 1; i >= 0; i--) out.push({ t: cur - i * MIN, o: price, h: price + 0.0001, l: price - 0.0001, c: price });
  return out;
}

export function fakeProvider(clock, { stale = false, fail = null } = {}) {
  const p = {
    name: 'FAKE', isDemo: false, configured: true, calls: 0, stale, fail,
    async fetchCandles() {
      p.calls++;
      if (p.fail) throw p.fail;
      const now = clock.now;
      return candlesUntil(p.stale ? now - 10 * MIN : now);
    },
  };
  return p;
}

export function fakePush({ configured = true, failWith = null } = {}) {
  const p = {
    configured, publicKey: 'pub', sent: [],
    async send(sub, payload) {
      if (p.failWith) throw p.failWith;
      p.sent.push({ sub, payload });
    },
    failWith,
  };
  return p;
}

export const SUB = { endpoint: 'https://push.example.test/abc', keys: { p256dh: 'p', auth: 'a' } };

export const callResult = (over = {}) => ({
  decision: 'CALL', direction: 'CALL', score: 6, maxScore: 7, expirySec: 60,
  parts: [{ key: 'trend5m', weight: 2, ok: true, text: 'x' }], warnings: [], summary: 'CALL setup', indicators: {}, ...over,
});
export const waitResult = () => ({ decision: 'WAIT', direction: null, score: 2, maxScore: 7, parts: [], warnings: [], summary: 'No high-quality setup' });
