import test from 'node:test';
import assert from 'node:assert/strict';
import { analyze } from '../src/analysis.js';

const MIN = 60000, T = Date.UTC(2026, 9, 13, 12, 0, 0);

// Deterministic synthetic candle builder (closes -> OHLC). Synthetic data only, used to unit-test the rules.
function build(closes, wick = 0.00004) {
  const out = []; let prev = closes[0];
  closes.forEach((c, i) => {
    const o = prev;
    out.push({ t: T + (i - closes.length) * MIN, o, h: Math.max(o, c) + wick, l: Math.min(o, c) - wick, c });
    prev = c;
  });
  return out;
}
function trend(n, slope, noise) {
  const cl = [];
  for (let i = 0; i < n; i++) cl.push(1.1 + slope * i + noise * Math.sin(i * 0.9) + noise * 0.6 * Math.sin(i * 0.37));
  return cl;
}
function pullbackSetup() {
  const cl = trend(240, 0.00001, 0.00005);
  let p = cl[cl.length - 1];
  for (let k = 0; k < 4; k++) { p -= 0.00006; cl.push(p); }
  cl.push(p + 0.0002);
  return cl;
}
const mirror = (cl) => cl.map((c) => 2 * 1.1 - c);

test('trend pullback with confirmation -> CALL, with explanation and expiry', () => {
  const r = analyze(build(pullbackSetup()), { minScore: 6 });
  assert.equal(r.decision, 'CALL');
  assert.ok(r.score >= 6 && r.score <= 7);
  assert.ok([60, 300].includes(r.expirySec));
  assert.ok(r.parts.length === 6 && r.parts.some((p) => p.ok));
  assert.equal(r.vetoes.length, 0);
});

test('mirrored downtrend pullback -> PUT', () => {
  const r = analyze(build(mirror(pullbackSetup())), { minScore: 6 });
  assert.equal(r.decision, 'PUT');
});

test('raising the minimum score to 7 can only make signals rarer, never wider', () => {
  const strict = analyze(build(pullbackSetup()), { minScore: 7 });
  const loose = analyze(build(pullbackSetup()), { minScore: 6 });
  assert.ok(strict.decision === 'WAIT' || strict.score === 7);
  assert.ok(loose.decision !== 'WAIT' || strict.decision === 'WAIT');
});

test('smooth overextended rally is blocked (RSI veto), not chased', () => {
  const cl = trend(240, 0.00003, 0.00004);
  let p = cl[cl.length - 1];
  for (const d of [-0.00006, -0.00008, -0.00005, 0.00016]) { p += d; cl.push(p); }
  const r = analyze(build(cl));
  assert.equal(r.decision, 'WAIT');
  assert.match(r.summary, /RSI .* overbought/);
});

test('flat market -> WAIT', () => {
  const cl = Array.from({ length: 260 }, (_, i) => 1.1 + 0.00003 * Math.sin(i * 0.7));
  assert.equal(analyze(build(cl)).decision, 'WAIT');
});

test('sudden volatility spike -> WAIT (volatility veto)', () => {
  const cl = pullbackSetup();
  cl.push(cl[cl.length - 1] + 0.003);
  const r = analyze(build(cl));
  assert.equal(r.decision, 'WAIT');
  assert.match(r.summary, /Volatility too high/);
});

test('missing candles in the window -> WAIT (data gaps)', () => {
  const cs = build(pullbackSetup());
  const holey = cs.filter((_, i) => !(i > 120 && i < 140));
  const r = analyze(holey);
  assert.equal(r.decision, 'WAIT');
  assert.match(r.summary, /missing candles/);
});

test('too little data -> WAIT, never a signal', () => {
  const r = analyze(build(pullbackSetup()).slice(-60));
  assert.equal(r.decision, 'WAIT');
  assert.match(r.summary, /Not enough data/);
});

test('result never contains a probability or guarantee wording', () => {
  const r = analyze(build(pullbackSetup()));
  assert.ok(!/guarantee|certain|sure win|probability/i.test(JSON.stringify(r)));
});
