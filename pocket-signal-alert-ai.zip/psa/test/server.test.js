import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server.js';
import { Monitor } from '../src/monitor.js';
import { MIN, T0, tmpStore, cfg, fakeProvider, fakePush, SUB, callResult } from './helpers.js';

const KEY = 'k'.repeat(20);

async function boot() {
  const clock = { now: T0 };
  const config = cfg({ appKey: KEY });
  const store = tmpStore();
  const push = fakePush();
  const monitor = new Monitor({ config, store, provider: fakeProvider(clock), push, analyzer: () => callResult(), now: () => clock.now, log: { error() {} } });
  const server = createApp({ config, store, monitor, push });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = (path, { method = 'GET', body, key = KEY } = {}) => fetch(base + path, {
    method, headers: { 'content-type': 'application/json', ...(key ? { 'x-app-key': key } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { server, call, store, push, monitor, clock, base };
}

test('API requires the app key; health and VAPID public key are open', async () => {
  const { server, call } = await boot();
  assert.equal((await call('/api/status', { key: null })).status, 401);
  assert.equal((await call('/api/status', { key: 'wrong-wrong-wrong-wrong' })).status, 401);
  assert.equal((await call('/api/status')).status, 200);
  assert.equal((await call('/api/health', { key: null })).status, 200);
  const v = await (await call('/api/vapid-public-key', { key: null })).json();
  assert.equal(v.publicKey, 'pub');
  server.closeAllConnections(); server.close();
});

test('subscribe validates and stores device; test push reaches the push layer', async () => {
  const { server, call, store, push } = await boot();
  assert.equal((await call('/api/subscribe', { method: 'POST', body: { subscription: { endpoint: 'http://insecure', keys: {} } } })).status, 400);
  assert.equal((await call('/api/subscribe', { method: 'POST', body: { subscription: SUB } })).status, 200);
  assert.equal(store.data.subscriptions.length, 1);
  const r = await (await call('/api/test-push', { method: 'POST' })).json();
  assert.equal(r.sent, 1);
  assert.match(push.sent[0].payload.title, /TEST/);
  assert.match(push.sent[0].payload.body, /NOT a trading signal/);
  server.closeAllConnections(); server.close();
});

test('settings are validated', async () => {
  const { server, call } = await boot();
  assert.equal((await call('/api/settings', { method: 'POST', body: { pairs: ['FAKE/PAIR'] } })).status, 400);
  assert.equal((await call('/api/settings', { method: 'POST', body: { expiries: [45] } })).status, 400);
  assert.equal((await call('/api/settings', { method: 'POST', body: { minScore: 2 } })).status, 400);
  assert.equal((await call('/api/settings', { method: 'POST', body: { tz: 'Nope/Zone' } })).status, 400);
  const ok = await call('/api/settings', { method: 'POST', body: { pairs: ['EUR/USD', 'GBP/USD'], expiries: [60], minScore: 7, tz: 'Europe/London' } });
  assert.equal(ok.status, 200);
  assert.deepEqual((await ok.json()).settings.pairs, ['EUR/USD', 'GBP/USD']);
  server.closeAllConnections(); server.close();
});

test('start monitoring, generate one signal, record outcome, reset history', async () => {
  const { server, call, monitor, store } = await boot();
  store.data.settings.monitoring = true;
  await call('/api/subscribe', { method: 'POST', body: { subscription: SUB } });
  await monitor.cycle();
  const st = await (await call('/api/status')).json();
  assert.equal(st.state, 'ACTIVE SIGNAL');
  assert.equal(st.signalsToday, 1);
  const id = st.active.id;
  assert.equal((await call(`/api/history/${id}/outcome`, { method: 'POST', body: { result: 'loss' } })).status, 200);
  assert.equal((await call(`/api/history/${id}/outcome`, { method: 'POST', body: { result: 'nope' } })).status, 400);
  assert.equal((await call('/api/history', { method: 'DELETE' })).status, 200);
  assert.equal((await (await call('/api/history')).json()).history.length, 0);
  server.closeAllConnections(); server.close();
});

test('static files served; path traversal blocked', async () => {
  const { server, base } = await boot();
  const trav = await fetch(base + '/%2e%2e%2fserver.js');
  assert.ok([403, 404].includes(trav.status));
  assert.equal((await fetch(base + '/server.js')).status, 404);
  server.closeAllConnections(); server.close();
  void MIN;
});
