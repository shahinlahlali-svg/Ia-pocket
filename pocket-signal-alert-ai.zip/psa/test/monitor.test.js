import test from 'node:test';
import assert from 'node:assert/strict';
import { Monitor } from '../src/monitor.js';
import { MIN, T0, tmpStore, cfg, fakeProvider, fakePush, SUB, callResult, waitResult } from './helpers.js';

function setup({ analyzer, provider, push, config } = {}) {
  const clock = { now: T0 };
  const store = tmpStore();
  store.data.settings.pairs = ['EUR/USD'];
  store.data.subscriptions = [SUB];
  const prov = provider || fakeProvider(clock);
  const pu = push || fakePush();
  const m = new Monitor({
    config: cfg(config), store, provider: prov, push: pu,
    analyzer: analyzer || (() => callResult()), now: () => clock.now, log: { error() {} },
  });
  store.data.settings.monitoring = true;
  return { clock, store, prov, pu, m };
}

test('WAIT result: no signal and no push', async () => {
  const { m, pu, store } = setup({ analyzer: waitResult });
  await m.cycle();
  assert.equal(pu.sent.length, 0);
  assert.equal(store.data.history.length, 0);
  assert.equal(m.getStatus().state, 'WAIT');
});

test('valid setup: exactly one signal and one push per device', async () => {
  const { m, pu, store } = setup();
  await m.cycle();
  assert.equal(store.data.history.length, 1);
  assert.equal(pu.sent.length, 1);
  const p = pu.sent[0].payload;
  assert.match(p.title, /POCKET SIGNAL ALERT/);
  assert.match(p.body, /EUR\/USD/);
  assert.match(p.body, /CALL/);
  assert.match(p.body, /1 minute/);
  assert.match(p.body, /manually/);
  assert.equal(m.getStatus().state, 'ACTIVE SIGNAL');
});

test('only one active signal: no new fetch or alert until it expires', async () => {
  const { m, pu, prov, clock } = setup();
  await m.cycle();
  const calls = prov.calls;
  for (let i = 1; i <= 3; i++) { clock.now += 10000; await m.cycle(); }
  assert.equal(prov.calls, calls, 'must not fetch while a signal is active');
  assert.equal(pu.sent.length, 1);
});

test('same setup and cooldown suppress duplicates; new setup after cooldown fires', async () => {
  const { m, pu, clock, store } = setup();
  await m.cycle();
  const sig = store.data.history[0];
  clock.now = sig.expiresAt + 1000; // signal expired, same minute-candle context
  // Same closed candle (fingerprint) -> duplicate
  clock.now = sig.detectedAt + 100 * 1000; // after expiry but within cooldown
  await m.cycle();
  assert.equal(pu.sent.length, 1, 'duplicate/cooldown must not alert');
  // Past cooldown (600s) with a different closed candle -> allowed again
  clock.now = sig.detectedAt + 11 * MIN;
  await m.cycle();
  assert.equal(pu.sent.length, 2);
});

test('several pairs: only the single highest-scoring setup alerts', async () => {
  let i = 0;
  const scores = { 'EUR/USD': 6, 'GBP/USD': 7 };
  const { m, pu, store } = setup({ analyzer: () => callResult({ score: 6 }) });
  store.data.settings.pairs = ['EUR/USD', 'GBP/USD'];
  const orig = m.checkPair.bind(m);
  m.checkPair = async (pair, now) => { const r = await orig(pair, now); return r ? { ...r, score: scores[pair] } : r; };
  await m.cycle();
  assert.equal(store.data.history.length, 1);
  assert.equal(store.data.history[0].pair, 'GBP/USD');
  assert.equal(pu.sent.length, 1);
  void i;
});

test('stale data -> DATA UNAVAILABLE, no signal, no push', async () => {
  const clock = { now: T0 };
  const { m, pu, store } = setup({ provider: fakeProvider(clock, { stale: true }) });
  m.provider.fetchCandles = async () => { const { candlesUntil } = await import('./helpers.js'); return candlesUntil(T0 - 10 * MIN); };
  await m.cycle();
  const st = m.getStatus();
  assert.equal(st.state, 'DATA UNAVAILABLE');
  assert.match(st.pairs[0].detail, /stale/i);
  assert.equal(store.data.history.length, 0);
  assert.equal(pu.sent.length, 0);
});

test('provider failure -> DATA UNAVAILABLE and error shown', async () => {
  const clock = { now: T0 };
  const err = Object.assign(new Error('Provider unreachable'), { code: 'NETWORK' });
  const { m, pu } = setup({ provider: fakeProvider(clock, { fail: err }) });
  await m.cycle();
  const st = m.getStatus();
  assert.equal(st.state, 'DATA UNAVAILABLE');
  assert.equal(st.provider.state, 'error');
  assert.equal(pu.sent.length, 0);
});

test('real analyzer refuses to signal on insufficient data', async () => {
  const { analyze } = await import('../src/analysis.js');
  const { candlesUntil } = await import('./helpers.js');
  const r = analyze(candlesUntil(T0, 40), { minCandles: 150 });
  assert.equal(r.decision, 'WAIT');
  assert.match(r.summary, /Not enough data/);
});

test('signal is still recorded when push is not configured, with a clear error', async () => {
  const { m, store } = setup({ push: fakePush({ configured: false }) });
  await m.cycle();
  assert.equal(store.data.history.length, 1);
  assert.match(store.data.history[0].push.error, /not configured/i);
});

test('expired/gone push subscription (410) is removed', async () => {
  const gone = Object.assign(new Error('gone'), { statusCode: 410 });
  const { m, store } = setup({ push: fakePush({ failWith: gone }) });
  await m.cycle();
  assert.equal(store.data.subscriptions.length, 0);
  assert.equal(store.data.history[0].push.removed, 1);
});

test('daily API budget stops requests', async () => {
  const { m, prov } = setup({ config: { dailyRequestLimit: 1 }, analyzer: waitResult });
  await m.cycle();
  m.clockAdvance = 0;
  await m.cycle();
  assert.equal(prov.calls, 1);
  assert.match(m.getStatus().pairs[0].detail, /limit/i);
});

test('outcomes and stats only count recorded wins/losses, demo separated', async () => {
  const { m, store, clock } = setup();
  await m.cycle();
  const id = store.data.history[0].id;
  assert.equal(m.recordOutcome(id, 'win'), true);
  assert.equal(m.recordOutcome(id, 'bogus'), false);
  const s = m.stats();
  assert.equal(s.live.wins, 1);
  assert.equal(s.live.winRate, 1);
  assert.equal(s.demo.total, 0);
  void clock;
});

test('restart restores an unexpired active signal (no second alert)', async () => {
  const { m, store, clock, pu } = setup();
  await m.cycle();
  const m2 = new Monitor({ config: cfg(), store, provider: fakeProvider(clock), push: pu, analyzer: () => callResult(), now: () => clock.now, log: { error() {} } });
  await m2.cycle();
  assert.equal(pu.sent.length, 1);
  assert.equal(m2.getStatus().state, 'ACTIVE SIGNAL');
});
